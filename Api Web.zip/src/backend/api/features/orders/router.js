// Ghi chu: Export router chinh cho feature orders
const orderRoutes = require('./routes/orderRoutes');

module.exports = {
  ordersRouter: orderRoutes,
};
